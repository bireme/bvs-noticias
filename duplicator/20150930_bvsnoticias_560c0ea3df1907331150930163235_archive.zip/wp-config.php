<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'bvs-noticias');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'n<d&qh-[Rz0QEWu*J0&2lvD+8vzf(i-:^zOA$BNx;%=--Q0+~R=v-ffBvrM,!4}t');
define('SECURE_AUTH_KEY',  'HWY1^h:Z4%#Pl94pG=6]=ra,~OsT6x:t5ek5|RH2]%do[ucv<U}-<QtQN,8qS=JB');
define('LOGGED_IN_KEY',    '_qfE}8%M2Rj-RQVPQ)tEI|}EV-_}k|W-lc#H|<FB#l%x(dHM?rOO;:*V^} O[[(:');
define('NONCE_KEY',        'MS1O.T,A+,# _/emT_XWA~Z+z*8aCmi_>qX*AJg3+v[1)tF|i#NONKoigS:E|CG@');
define('AUTH_SALT',        '$*@f|]+nXH$(4+a2POB&|!~A^U6p3IxB4_ZCkH6PgPfHDiw6@pE{OZz.)#cl5^Dl');
define('SECURE_AUTH_SALT', 'm p|>>wg*#f fr-kPd+KXW~5n2@Pi3?EIXI_F}rR}-.INWT8vVFu&2jNk[ ^2IWc');
define('LOGGED_IN_SALT',   'U5~PrnV(<>m~z?!zyFx*^.D$ih%jj60I.ACCpB/D[8+] Kaq$`iGBhbtoq5f68fJ');
define('NONCE_SALT',       '0*J;1ir$+mUth8v}+2BK(AbbL{|[^!e?V+7U:t,-|UAeWgsC%)9tIW}|m1h)74Ah');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
